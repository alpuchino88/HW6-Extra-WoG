from Live import load_game, welcome
welcome()
load_game()
